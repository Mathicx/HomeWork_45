package controllers.templates;
import com.sun.net.httpserver.HttpExchange;
import controllers.Controller;
import models.SampleBook;
import servlets.TemplateServlet;
import java.io.IOException;

public class BookController implements Controller {

    private final TemplateServlet<SampleBook> handler = new TemplateServlet<SampleBook>();

    @Override
    public void handle(HttpExchange exchange) throws IOException
    {
        handler.handle(exchange, "book.html", new SampleBook());
    }
}
