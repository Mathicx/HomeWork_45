package controllers.templates;
import com.sun.net.httpserver.HttpExchange;
import controllers.Controller;
import models.SampleLibraryReader;
import models.SampleSingleReader;
import servlets.TemplateServlet;
import java.io.IOException;

public class LibraryReadersController implements Controller {

    private final TemplateServlet<SampleLibraryReader> handler = new TemplateServlet<SampleLibraryReader>();

    @Override
    public void handle(HttpExchange exchange) throws IOException
    {
        handler.handle(exchange, "LibraryReaders.html", new SampleLibraryReader());
    }
}



