package controllers.templates;

import com.sun.net.httpserver.HttpExchange;
import controllers.Controller;
import models.SampleBook;
import models.SampleBookDetails;
import servlets.TemplateServlet;

import java.io.IOException;

public class BookDetailsController implements Controller{


        private final TemplateServlet<SampleBookDetails> handler = new TemplateServlet<SampleBookDetails>();

        @Override
        public void handle(HttpExchange exchange) throws IOException
        {
            handler.handle(exchange, "bookDetails.html", new SampleBookDetails());
        }
    }

