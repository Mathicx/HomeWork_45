package controllers.templates;

import com.sun.net.httpserver.HttpExchange;
import controllers.Controller;
import models.SampleSingleReader;
import servlets.TemplateServlet;

import java.io.IOException;

public class ReaderController implements Controller {
    private final TemplateServlet<SampleSingleReader> handler = new TemplateServlet<SampleSingleReader>();

    @Override
    public void handle(HttpExchange exchange) throws IOException
    {
        handler.handle(exchange, "SingleReader.html", new SampleSingleReader());
    }
}
