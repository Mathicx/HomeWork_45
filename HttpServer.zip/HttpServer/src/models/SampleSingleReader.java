package models;

public class SampleSingleReader {
    private LibraryReader reader;
    public SampleSingleReader() {
        this.reader = new SampleLibraryReader().getSingleReader();
    }

    public LibraryReader getReader()
    {
        return reader;
    }
}
