package models;


import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class SampleLibraryReader {
    private final List<LibraryReader> readers = new ArrayList<>();
    Random random = new Random();
    public SampleLibraryReader() {
        readers.add(new LibraryReader(1, "Kasym", "Tokaev", "toka@akorda.kz", "+7(777)777-7777"));
        readers.add(new LibraryReader(2, "Vova", "Putin", "vova@kremlin.ru", "+9(999)999-9999"));
        readers.add(new LibraryReader(3, "See", "Zinpin", "sizi@beijing.cn", "+8(888)888-8888"));
        readers.add(new LibraryReader(4, "Jon", "Baiden", "joba@whitehouse.us", "+6(666)666-6666"));
        readers.add(new LibraryReader(5, "Redjep", "Erdogan", "erdg@ankara.tk", "+5(555)555-55555"));
    }

    public List<LibraryReader> getReaders() {
        return readers;
    }

    public LibraryReader getSingleReader(){
        return readers.get(random.nextInt(readers.size()));
    }
}
