package models;
import java.util.ArrayList;
import java.util.Random;

public class LibraryReader {
    private int readerID;
    private String name;
    private String surname;
    private String email;
    private String phoneNumber;

    private ArrayList<Integer> booksAtHand;
    private ArrayList<Integer> booksRead;
    Random rnd = new Random();


    public LibraryReader(int readerID, String name, String surname, String email, String phoneNumber) {
        this.readerID = readerID;
        this.name = name;
        this.surname = surname;
        this.email = email;
        this.phoneNumber = phoneNumber;
    }
    public int getReaderID() {
        return readerID;
    }
    public String getName() {
        return name;
    }
    public String getSurname() {
        return surname;
    }
    public String getEmail() {
        return email;
    }
    public String getPhoneNumber() {
        return phoneNumber;
    }
//    SampleBook books = (SampleBook) new SampleBook().getBooks();
    public void addBookToHand(SampleBook books) {
        if (booksAtHand.size() < 2)
        {
            int id = rnd.nextInt();
            booksAtHand.add(books.getSingleFreeBook().getBookID(id));
            booksRead.add(books.getSingleFreeBook().getBookID(id));
            System.out.println("Книга \"" + books.getSingleFreeBook().getBookName() + "\" добавлена на руки.");

        }
        else {System.out.println("У вас уже есть две книги на руках. Верните хотя бы одну, чтобы взять новую.");}

    }

    // Метод для возврата книги в библиотеку
    public void returnBookToLibrary(Book book) {
        if (booksAtHand.contains(book)) {
            booksAtHand.remove(book);
            System.out.println("Книга \"" + book.getBookName() + "\" возвращена в библиотеку.");
        } else {
            System.out.println("У вас нет такой книги на руках.");
        }
    }

}
