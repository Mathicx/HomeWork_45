package models;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class SampleBook {

    private final ArrayList<Book> books = new ArrayList<>();
    Random random = new Random();

    public SampleBook()
    {
        books.add(new Book(1,"Путь Абая", "М.Ауэзов", true, "https://biographe.ru/wp-content/uploads/2019/11/234234-5.png"));
        books.add(new Book(2,"Путь Ержана", "М.Жабаев", true, "https://upload.wikimedia.org/wikipedia/commons/5/56/Kiprensky_Pushkin.jpg"));
        books.add(new Book(3,"Путь Ермека", "А.Азор", true, "https://cdn-s-static.arzamas.academy/uploads/ckeditor/pictures/11935/content_660.jpg"));
        books.add(new Book(4,"Пусть говорят", "А.Малахов", true, "https://upload.wikimedia.org/wikipedia/commons/thumb/0/0c/Mark_Twain_by_AF_Bradley.jpg/274px-Mark_Twain_by_AF_Bradley.jpg"));
        books.add(new Book(5,"Переворот", "А.Соловьев", true, "https://upload.wikimedia.org/wikipedia/commons/thumb/7/77/Iwan_Nikolajewitsch_Kramskoj_006.jpg/220px-Iwan_Nikolajewitsch_Kramskoj_006.jpg"));
        books.add(new Book(6,"Книга6", "А.Втор6", false, "https://biographe.ru/wp-content/uploads/2019/11/234234-5.png"));
        books.add(new Book(7,"Книга7", "А.Втор7", false, "https://biographe.ru/wp-content/uploads/2019/11/234234-5.png"));
        books.add(new Book(8,"Книга8", "А.Втор8", false, "https://biographe.ru/wp-content/uploads/2019/11/234234-5.png"));
        books.add(new Book(9,"Книга9", "А.Втор9", false, "https://biographe.ru/wp-content/uploads/2019/11/234234-5.png"));
        books.add(new Book(10,"Книга10", "А.Втор10", false, "https://biographe.ru/wp-content/uploads/2019/11/234234-5.png"));
        books.add(new Book(11,"Книга11", "А.Втор6", false, "https://biographe.ru/wp-content/uploads/2019/11/234234-5.png"));
        books.add(new Book(12,"Книга12", "А.Втор7", false, "https://biographe.ru/wp-content/uploads/2019/11/234234-5.png"));
        books.add(new Book(13,"Книга13", "А.Втор8", false, "https://biographe.ru/wp-content/uploads/2019/11/234234-5.png"));
        books.add(new Book(14,"Книга14", "А.Втор9", false, "https://biographe.ru/wp-content/uploads/2019/11/234234-5.png"));
        books.add(new Book(15,"Книга15", "А.Втор10", false, "https://biographe.ru/wp-content/uploads/2019/11/234234-5.png"));
    }
    public List<Book> getBooks()
    {
        return books;
    }

    public Book getSingleBook(){
        return books.get(random.nextInt(books.size()));
    }
    public Book getSingleFreeBook() {
        int id = random.nextInt(books.size()+1);
        if(books.get(id).isStatus() == false)
        {
            return books.get(random.nextInt(books.size()));
        }
        else {
            System.out.println("Книга занята, выберите другую свободную книгу.");
        }
        return null;
    }
}



