package models;
import java.util.ArrayList;
import java.util.List;

public class SampleBookDetails {
    private Book book;
    public SampleBookDetails() {
        this.book = new SampleBook().getSingleBook();
    }

    public Book getBook()
        {
            return book;
        }


}


