package models;

public class Book {

    private int bookID;
    private String bookName;
    private String authorName;
    private boolean status;
    private String imagePath;
    public Book(int bookID, String bookName, String authorName, boolean status, String imagePath) {
        this.bookID = bookID;
        this.bookName = bookName;
        this.authorName = authorName;
        this.status = status;
        this.imagePath = imagePath;
    }

    public int getBookID(int id) {
        return bookID;
    }
    public String getBookName() {
        return bookName;
    }
    public String getAuthorName() {
        return authorName;
    }
    public boolean isStatus() {
        return status;
    }
    public String getImagePath() {
        return imagePath;
    }

    public void setBookID(int bookID) {
        this.bookID = bookID;
    }

    public void setBookName(String bookName) {
        this.bookName = bookName;
    }

    public void setAuthorName(String authorName) {
        this.authorName = authorName;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public void setImagePath(String imagePath) {
        this.imagePath = imagePath;
    }
}
